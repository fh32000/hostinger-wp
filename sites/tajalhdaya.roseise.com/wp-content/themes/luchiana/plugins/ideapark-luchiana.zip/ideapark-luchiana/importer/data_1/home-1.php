<?php
defined( 'ABSPATH' ) || exit;

$mods                                = [];
//$mods['custom_fonts']                =  '';

$theme_home = [
	'title'      => __( 'Main', 'ideapark-luchiana' ),
	'screenshot' => 'home-1.jpg',
	'url'        => 'https://parkofideas.com/luchiana/demo/',
	'mods'       => $mods,
	'options'    => [],
];